using UnityEngine;

public class PlayerStats : MonoBehaviour
{
    public static int points = 1000;  // Example points
}